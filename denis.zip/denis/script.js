$('.card').click(function(){
    $(this).toggleClass('flipped');
  });